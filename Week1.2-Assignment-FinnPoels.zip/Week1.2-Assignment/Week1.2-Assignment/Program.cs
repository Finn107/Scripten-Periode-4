﻿using System;

namespace Week1._2_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            student Finn = new student();
            Console.WriteLine(Finn.Name);
            Console.WriteLine(Finn.Hobby);
            Console.WriteLine(Finn.Yearofbirth);
            Console.WriteLine(Finn.Alive);

            Console.WriteLine();

            student Bob = new student("Bob", 2000, true, "Voetballen");
            Console.WriteLine(Bob.Name);
            Console.WriteLine(Bob.Hobby);
            Console.WriteLine(Bob.Yearofbirth);
            Console.WriteLine(Bob.Alive);

            Console.WriteLine();

            Bob.Alive = false;
            Console.WriteLine(Bob.Alive);

            Console.WriteLine(Bob.Status());

        }
    }
}
