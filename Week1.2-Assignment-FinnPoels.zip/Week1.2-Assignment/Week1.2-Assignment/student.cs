﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week1._2_Assignment
{
    class student
    {

        private string hobby;
        public string Hobby
        {
            get { return this.hobby; }
            set { this.hobby = value; }
        }

        private string name;
        public string Name
        {
            get { return this.name; }
        }

        private int yearofbirth;
        public int Yearofbirth
        {
            get { return this.yearofbirth; }
        }

        private bool alive = true;
        public bool Alive
        {
            get { return this.alive; }
            set { this.alive = value; }
        }

        public student()
        {
            this.name = "Finn";
            this.yearofbirth = 2000;
            this.alive = true;
            this.hobby = "Gaming";
        }

        public student(string name, int yearofbirth, bool alive, string hobby)
        {
            this.name = name;
            this.yearofbirth = yearofbirth;
            this.alive = alive;
            this.hobby = hobby;
        }

        public string Status()
        {
            if(this.alive == true)
            {
                return "Alive";
            }
            else
            {
                return "Not alive";
            }
        }

    }
}
